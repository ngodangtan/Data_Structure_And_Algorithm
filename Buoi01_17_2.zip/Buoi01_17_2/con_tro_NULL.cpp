//
// Created by Felix Ngo on 17/2/25.
//

#include <iostream>
using namespace std;

int main() {

  int x;
  cout << x << endl;

  int* p1 = NULL;
  return 0;
}